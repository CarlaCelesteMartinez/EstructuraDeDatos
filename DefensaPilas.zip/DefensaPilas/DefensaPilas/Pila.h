#pragma once

#define MAX 10

class Pila
{
private:
	int pila[MAX];
	int tope;

public:
	Pila(void);
	~Pila(void);

	int gettope();
	bool Apilar(int elemento);
	bool Desapilar();
	void verpila();
	bool pilallena();
	bool pilavacia();
	int ValorTope();
	int getValor(int i);
};

