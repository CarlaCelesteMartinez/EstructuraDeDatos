#include "stdafx.h"
#include <iostream>
#include "Rectangulo.h"
#include "Paralelogramo.h"
#include "conio.h"

using namespace std;


int main(){
	Rectangulo rect;
	Paralelogramo para;

	para.setWidth(5);
	para.setHeight(9);
	
	rect.setWidth(5);
	rect.setHeight(7);

	cout<<"Total area: "<< rect.getArea() << endl;
	cout << "Total area paralelogramo : "<< para.Get_Area()<< endl;

	getch();

}