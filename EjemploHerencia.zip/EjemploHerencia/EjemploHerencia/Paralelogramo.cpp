#include "StdAfx.h"
#include "Paralelogramo.h"


Paralelogramo::Paralelogramo(void)
{
}

Paralelogramo::~Paralelogramo(void)
{
}

int Paralelogramo::Get_Area()
{
	return (width* height);
}