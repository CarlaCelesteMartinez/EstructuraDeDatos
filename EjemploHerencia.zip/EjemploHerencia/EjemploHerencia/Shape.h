#pragma once
// Base class
class Shape {
protected: ///atributos
      int width;
      int height;   
public:///metodos
      void setWidth(int w);
      void setHeight(int h);
	  
};