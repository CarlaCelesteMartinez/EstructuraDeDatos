#include "stdafx.h"
#include <iostream>
#include "Vector.h"
#include "conio.h"

#define MAX 100  //MAX es una constante definida por compilador

using namespace std;

void main()
{
	float vector01[MAX];
	int n;
	Vector vector1;
	do{
		cout<<"ingrese el tama�o del vector:";
		cin>>n;
	}

	while((n>MAX) || (n<=0));
	vector1.cargarVector(vector01,n);
	vector1.mostrarVector(vector01,n);
	vector1.formula(vector01,n);
	getch();

	
}