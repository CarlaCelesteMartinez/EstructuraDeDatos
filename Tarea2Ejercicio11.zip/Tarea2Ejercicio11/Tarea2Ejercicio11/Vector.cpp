#include "StdAfx.h"
#include "Vector.h"
#include <iostream>
#define MAX 100

using namespace std;


Vector::Vector(void)
{
	vector01[MAX]=0;
	n=0;
}


Vector::~Vector(void)
{
}

void Vector::cargarVector(float vector01[],int n)
{
	for(int i=0; i<n; i++)
	{
		cout<<"vector1["<<i<<"]"; 
		cin>>vector01[i];
	}
}
void Vector::mostrarVector(float vector01[],int n)
{
	for(int i=0; i<n; i++)
	{
		cout<<vector01[i]<<", ";
	}
	cout<<endl;
}
void Vector::formula(float vector01[],int n)
{
	int positivo=0;
	int negativo=0;
	int cero=0;
	int positivofinal=0;
	

	for(int i=0; i<n; i++)
	{
		if(vector01[i]>=0)
		{
			positivo=positivo+1;
			if(vector01[i]==0)
			{
				cero=cero+1;
			}
		}

		else
		{
			negativo=negativo+1;
			
		}
		positivofinal=positivo-cero;
	}

	cout<<"positivos igual a: "<<positivofinal<<endl;
	cout<<"negativo igual a: "<<negativo<<endl;
	cout<<"cero igual a: "<<cero<<endl;
}