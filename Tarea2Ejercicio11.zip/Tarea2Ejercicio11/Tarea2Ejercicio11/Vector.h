#pragma once
#define MAX 100
class Vector
{
private:
	float vector01[MAX];
	int n;
	int positivo;
	int negativo;
	int cero;
	int positivofinal;

public:
	Vector(void);  
	~Vector(void);  

	void cargarVector(float vector01[], int n);
	void mostrarVector(float vector01[], int n);
	void formula(float vector01[],int n);
	

};