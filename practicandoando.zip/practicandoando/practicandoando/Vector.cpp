#include "StdAfx.h"
#include "Vector.h"
#include <iostream>

#define MAX 100

using namespace std;

Vector::Vector(void)
{
	vector01[MAX]=0;
	n=0;
}


Vector::~Vector(void)
{
}

void Vector::cargarVector(float vector01[], int n)
{
	for(int i=0; i<n; i++)
	{
		cout<<"vector1["<<i<<"]";
		cin>>vector01[i];
	}
}

void Vector::mostrarVector(float vector01[], int n)
{
	for(int i=0; i<n; i++)
	{
		cout<<vector01[i]<<", ";
	}
	cout<<endl;
}

void Vector::ordenarasc(float vector01[], int n)
{
	int aux;
	for(int i=1; i<n; i++)
	{
		for(int j=0; j<n-1; j++)
		{
			if(vector01[j]>vector01[j+1])
			{
				aux=vector01[j];
				vector01[j]=vector01[j+1];
				vector01[j+1]=aux;
			}
		}
	}
}

void Vector::ordenardescendente(float vector01[], int n)
{
	int aux;
	for(int i=1; i<n; i++)
	{
		for(int j=0; j<n-1; j++)
		{
			if(vector01[j]<vector01[j+1])
			{
				aux=vector01[j];
				vector01[j]=vector01[j+1];
				vector01[j+1]=aux;
			}
		}
	}
}