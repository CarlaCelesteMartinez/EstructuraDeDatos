#pragma once
#define MAX 100

class Vector
{
private:
	float vector01[MAX];
	int n;

public:
	Vector(void);
	~Vector(void);

	void cargarVector(float vector01[], int n);
	void mostrarVector(float vector01[], int n);
	void ordenarasc(float vector01[], int n);
	void ordenardescendente(float vector01[], int n);
};

