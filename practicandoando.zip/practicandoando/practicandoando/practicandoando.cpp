// practicandoando.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include "Vector.h"
#include <iostream>
#include "conio.h"

#define MAX 100

using namespace std;

void main()
{
	float vector01[MAX];
	int n;
	int op;
	Vector vectorsito;
	
	do
	{
		cout<<"ingrese el tama�o del vector:";
		cin>>n;
	}

	while((n>MAX) || (n<=0));
	do
	{
		cout<<"------   MENU   ------"<<endl;
		cout<<"|1.- Cargar Vector     |"<<endl;
		cout<<"|2.- Mostrar Vector    |"<<endl;
		cout<<"|3.-Ordenar ascendente |"<<endl;
		cout<<"|4.-Ordenar descendente|"<<endl;
		cout<<"|0.- Salir			  |"<<endl;
		cout<<"-----------------------"<<endl;
		cout<<"elija una opcion"<<endl;
		cin>>op;
		switch(op)
		{
		case 1:
			vectorsito.cargarVector(vector01, n);
			break;
		case 2:
			vectorsito.mostrarVector(vector01, n);
			break;
		case 3:
			vectorsito.ordenarasc(vector01, n);
			vectorsito.mostrarVector(vector01, n);
			break;
		case 4:
			vectorsito.ordenardescendente(vector01, n);
			vectorsito.mostrarVector(vector01, n);
			break;
		}
	}
	while(op>0);
}

