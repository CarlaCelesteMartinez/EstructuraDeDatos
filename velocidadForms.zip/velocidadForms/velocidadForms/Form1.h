#pragma once
#include "Velocidad.h"
#include "iostream"
#include "msclr\marshal_cppstd.h"

namespace velocidadForms {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtDistancia;
	private: System::Windows::Forms::TextBox^  txtTiempo;
	protected: 

	protected: 

	private: System::Windows::Forms::Label^  lblDistancia;
	private: System::Windows::Forms::Label^  lblTiempo;
	private: System::Windows::Forms::Button^  btnCalcular;



	private: System::Windows::Forms::TextBox^  txtResultado;

	private: System::Windows::Forms::Label^  label3;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtDistancia = (gcnew System::Windows::Forms::TextBox());
			this->txtTiempo = (gcnew System::Windows::Forms::TextBox());
			this->lblDistancia = (gcnew System::Windows::Forms::Label());
			this->lblTiempo = (gcnew System::Windows::Forms::Label());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->txtResultado = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// txtDistancia
			// 
			this->txtDistancia->Location = System::Drawing::Point(101, 39);
			this->txtDistancia->Name = L"txtDistancia";
			this->txtDistancia->Size = System::Drawing::Size(100, 22);
			this->txtDistancia->TabIndex = 0;
			// 
			// txtTiempo
			// 
			this->txtTiempo->Location = System::Drawing::Point(101, 99);
			this->txtTiempo->Name = L"txtTiempo";
			this->txtTiempo->Size = System::Drawing::Size(100, 22);
			this->txtTiempo->TabIndex = 1;
			// 
			// lblDistancia
			// 
			this->lblDistancia->AutoSize = true;
			this->lblDistancia->Location = System::Drawing::Point(12, 39);
			this->lblDistancia->Name = L"lblDistancia";
			this->lblDistancia->Size = System::Drawing::Size(66, 17);
			this->lblDistancia->TabIndex = 2;
			this->lblDistancia->Text = L"Distancia";
			this->lblDistancia->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// lblTiempo
			// 
			this->lblTiempo->AutoSize = true;
			this->lblTiempo->Location = System::Drawing::Point(16, 102);
			this->lblTiempo->Name = L"lblTiempo";
			this->lblTiempo->Size = System::Drawing::Size(55, 17);
			this->lblTiempo->TabIndex = 3;
			this->lblTiempo->Text = L"Tiempo";
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(117, 150);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(75, 23);
			this->btnCalcular->TabIndex = 4;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// txtResultado
			// 
			this->txtResultado->Location = System::Drawing::Point(101, 204);
			this->txtResultado->Name = L"txtResultado";
			this->txtResultado->Size = System::Drawing::Size(100, 22);
			this->txtResultado->TabIndex = 5;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(12, 204);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(72, 17);
			this->label3->TabIndex = 6;
			this->label3->Text = L"Resultado";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(282, 253);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txtResultado);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->lblTiempo);
			this->Controls->Add(this->lblDistancia);
			this->Controls->Add(this->txtTiempo);
			this->Controls->Add(this->txtDistancia);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
			 Velocidad velocidadclon;
			 velocidadclon.Set_distancia(System::Convert::ToInt32(txtDistancia->Text));
			 velocidadclon.Set_tiempo(System::Convert::ToInt32(txtTiempo->Text));
			 int areafin;
			 areafin=velocidadclon.Calcular();
			 txtResultado->Text=System::Convert::ToString(areafin);
		 }
};
}

